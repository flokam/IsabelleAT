object HOL {

trait equal[A] {
  val `HOL.equal`: (A, A) => Boolean
}
def equal[A](a: A, b: A)(implicit A: equal[A]): Boolean = A.`HOL.equal`(a, b)
object equal {
  implicit def `Set.equal_set`[A : equal]: equal[Set.set[A]] = new
    equal[Set.set[A]] {
    val `HOL.equal` = (a: Set.set[A], b: Set.set[A]) => Set.equal_seta[A](a, b)
  }
}

def eq[A : equal](a: A, b: A): Boolean = equal[A](a, b)

} /* object HOL */

object Product_Type {

def fst[A, B](x0: (A, B)): A = x0 match {
  case (x1, x2) => x1
}

def snd[A, B](x0: (A, B)): B = x0 match {
  case (x1, x2) => x2
}

def equal_prod[A : HOL.equal, B : HOL.equal](x0: (A, B), x1: (A, B)): Boolean =
  (x0, x1) match {
  case ((x1, x2), (y1, y2)) => HOL.eq[A](x1, y1) && HOL.eq[B](x2, y2)
}

} /* object Product_Type */

object Lista {

def fold[A, B](f: A => B => B, x1: List[A], s: B): B = (f, x1, s) match {
  case (f, x :: xs, s) => fold[A, B](f, xs, (f(x))(s))
  case (f, Nil, s) => s
}

def filter[A](p: A => Boolean, x1: List[A]): List[A] = (p, x1) match {
  case (p, Nil) => Nil
  case (p, x :: xs) => (if (p(x)) x :: filter[A](p, xs) else filter[A](p, xs))
}

def member[A : HOL.equal](x0: List[A], y: A): Boolean = (x0, y) match {
  case (Nil, y) => false
  case (x :: xs, y) => HOL.eq[A](x, y) || member[A](xs, y)
}

def insert[A : HOL.equal](x: A, xs: List[A]): List[A] =
  (if (member[A](xs, x)) xs else x :: xs)

def list_ex[A](p: A => Boolean, x1: List[A]): Boolean = (p, x1) match {
  case (p, Nil) => false
  case (p, x :: xs) => p(x) || list_ex[A](p, xs)
}

def removeAll[A : HOL.equal](x: A, xa1: List[A]): List[A] = (x, xa1) match {
  case (x, Nil) => Nil
  case (x, y :: xs) =>
    (if (HOL.eq[A](x, y)) removeAll[A](x, xs) else y :: removeAll[A](x, xs))
}

def list_all[A](p: A => Boolean, x1: List[A]): Boolean = (p, x1) match {
  case (p, Nil) => true
  case (p, x :: xs) => p(x) && list_all[A](p, xs)
}

} /* object Lista */

object Set {

abstract sealed class set[A]
final case class seta[A](a: List[A]) extends set[A]
final case class coset[A](a: List[A]) extends set[A]

def member[A : HOL.equal](x: A, xa1: set[A]): Boolean = (x, xa1) match {
  case (x, coset(xs)) => ! (Lista.member[A](xs, x))
  case (x, seta(xs)) => Lista.member[A](xs, x)
}

def less_eq_set[A : HOL.equal](a: set[A], b: set[A]): Boolean = (a, b) match {
  case (coset(Nil), seta(Nil)) => false
  case (a, coset(ys)) => Lista.list_all[A](((y: A) => ! (member[A](y, a))), ys)
  case (seta(xs), b) => Lista.list_all[A](((x: A) => member[A](x, b)), xs)
}

def equal_seta[A : HOL.equal](a: set[A], b: set[A]): Boolean =
  less_eq_set[A](a, b) && less_eq_set[A](b, a)

def Bex[A](x0: set[A], p: A => Boolean): Boolean = (x0, p) match {
  case (seta(xs), p) => Lista.list_ex[A](p, xs)
}

def Ball[A](x0: set[A], p: A => Boolean): Boolean = (x0, p) match {
  case (seta(xs), p) => Lista.list_all[A](p, xs)
}

def remove[A : HOL.equal](x: A, xa1: set[A]): set[A] = (x, xa1) match {
  case (x, coset(xs)) => coset[A](Lista.insert[A](x, xs))
  case (x, seta(xs)) => seta[A](Lista.removeAll[A](x, xs))
}

def minus_set[A : HOL.equal](a: set[A], x1: set[A]): set[A] = (a, x1) match {
  case (a, coset(xs)) =>
    seta[A](Lista.filter[A](((x: A) => member[A](x, a)), xs))
  case (a, seta(xs)) =>
    Lista.fold[A, set[A]](((aa: A) => (b: set[A]) => remove[A](aa, b)), xs, a)
}

} /* object Set */

object MC {

trait state[A] {
  val `MC.state_transition`: (A, A) => Boolean
}
def state_transition[A](a: A, b: A)(implicit A: state[A]): Boolean =
  A.`MC.state_transition`(a, b)
object state {
}

} /* object MC */

object AT {

abstract sealed class attree[A]
final case class BaseAttack[A](a: (Set.set[A], Set.set[A])) extends attree[A]
final case class AndAttack[A](a: List[attree[A]], b: (Set.set[A], Set.set[A]))
  extends attree[A]
final case class OrAttack[A](a: List[attree[A]], b: (Set.set[A], Set.set[A]))
  extends attree[A]

def attack[A : MC.state](x0: attree[A]): (Set.set[A], Set.set[A]) = x0 match {
  case BaseAttack(b) => b
  case AndAttack(as, s) => s
  case OrAttack(as, s) => s
}

def is_attack_tree[A : HOL.equal : MC.state](x0: attree[A]): Boolean = x0 match
  {
  case BaseAttack(s) =>
    Set.Ball[A](Product_Type.fst[Set.set[A], Set.set[A]](s),
                 ((x: A) =>
                   Set.Bex[A](Product_Type.snd[Set.set[A], Set.set[A]](s),
                               ((a: A) => MC.state_transition[A](x, a)))))
  case AndAttack(as, s) =>
    (as match {
       case Nil =>
         Set.less_eq_set[A](Product_Type.fst[Set.set[A], Set.set[A]](s),
                             Product_Type.snd[Set.set[A], Set.set[A]](s))
       case List(a) =>
         is_attack_tree[A](a) &&
           Product_Type.equal_prod[Set.set[A], Set.set[A]](attack[A](a), s)
       case a :: ab :: list =>
         is_attack_tree[A](a) &&
           (HOL.eq[Set.set[A]](Product_Type.fst[Set.set[A],
         Set.set[A]](attack[A](a)),
                                Product_Type.fst[Set.set[A], Set.set[A]](s)) &&
             is_attack_tree[A](AndAttack[A](ab :: list,
     (Product_Type.snd[Set.set[A], Set.set[A]](attack[A](a)),
       Product_Type.snd[Set.set[A], Set.set[A]](s)))))
     })
  case OrAttack(as, s) =>
    (as match {
       case Nil =>
         Set.less_eq_set[A](Product_Type.fst[Set.set[A], Set.set[A]](s),
                             Product_Type.snd[Set.set[A], Set.set[A]](s))
       case List(a) =>
         is_attack_tree[A](a) &&
           (Set.less_eq_set[A](Product_Type.fst[Set.set[A], Set.set[A]](s),
                                Product_Type.fst[Set.set[A],
          Set.set[A]](attack[A](a))) &&
             Set.less_eq_set[A](Product_Type.snd[Set.set[A],
          Set.set[A]](attack[A](a)),
                                 Product_Type.snd[Set.set[A], Set.set[A]](s)))
       case a :: ab :: list =>
         is_attack_tree[A](a) &&
           (Set.less_eq_set[A](Product_Type.fst[Set.set[A],
         Set.set[A]](attack[A](a)),
                                Product_Type.fst[Set.set[A], Set.set[A]](s)) &&
             (Set.less_eq_set[A](Product_Type.snd[Set.set[A],
           Set.set[A]](attack[A](a)),
                                  Product_Type.snd[Set.set[A],
            Set.set[A]](s)) &&
               is_attack_tree[A](OrAttack[A](ab :: list,
      (Set.minus_set[A](Product_Type.fst[Set.set[A], Set.set[A]](s),
                         Product_Type.fst[Set.set[A],
   Set.set[A]](attack[A](a))),
        Product_Type.snd[Set.set[A], Set.set[A]](s))))))
     })
}

} /* object AT */
